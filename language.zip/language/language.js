/* ================================
   1. 안정적인 반응형 스케일 적용
================================ */
function applyScale(wrapperId, baseWidth) {
    const wrapper = document.querySelector(wrapperId);
    const container = wrapper.querySelector(".scale-container");

    const wrapperWidth = wrapper.clientWidth;

    // 안정적: 1 이상으로 커지지 않음
    const scale = Math.min(wrapperWidth / baseWidth, 1);

    container.style.transform = `scale(${scale})`;
}

window.addEventListener("resize", () => {
    applyScale("#consonant-wrapper", 700);
    applyScale("#vowel-wrapper", 700);
});

/* ================================
   2. stroke & circle 생성
================================ */
function createAndInitialize(container, data) {
    const box = $(container).empty();

    data.forEach(st => {

        // ● circle 타입
        if (st.type === "circle") {
            const $circle = $("<div>")
                .addClass("circle")
                .attr("id", st.id)
                .css({
                    left: st.initial.left,
                    top: st.initial.top,
                    width: st.final.size + "px",
                    height: st.final.size + "px",
                    color: st.color,   // border에 currentColor가 들어감
                    borderColor: st.color
                });
            box.append($circle);
            return;
        }

        // ● stroke 타입
        const width = st.final.width || 40;
        const height = 11;

        const $stroke = $("<div>")
            .addClass("stroke")
            .attr("id", st.id)
            .css({
                left: st.initial.left,
                top: st.initial.top,
                width: width + "px",
                height: height + "px",
                backgroundColor: st.color,
                transform: `rotate(${st.initial.rotate || 0}deg)`
            });

        box.append($stroke);
    });
}

/* ================================
   3. 애니메이션
================================ */
const ANIMATION_DURATION = 1500;

function startAnimation(data) {
    data.forEach(st => {
        $("#" + st.id)
            .delay(st.delay)
            .animate({ opacity: 1 }, 20)
            .animate({
                left: st.final.left,
                top: st.final.top
            }, ANIMATION_DURATION, "swing", function () {
                if (st.type !== "circle")
                    $(this).css("transform", `rotate(${st.final.rotate || 0}deg)`);
            });
    });
}

/* ================================
   4. 자음 데이터 — ㄱ~ㅁ 그대로 복구
================================ */
const CONSONANT_STROKES = [

/* ================================
   1행 — ㄱ ㄴ ㄷ ㄹ ㅁ ㅂ ㅅ
================================ */

/* ㄱ (col=0 → originX = 40) */
{ id:'g1', color:'#ff6b6b', final:{left:40, top:50, rotate:0}, initial:{left:-200, top:20}, delay:0 },
{ id:'g2', color:'#48dbfb', final:{left:88, top:58, rotate:90}, initial:{left:800, top:20}, delay:200 },

/* ㄴ (col=1 → originX = 120) */
{ id:'n1', color:'#6ac46a', final:{left:132, top:52, rotate:90}, initial:{left:-200, top:80}, delay:400 },
{ id:'n2', color:'#ff8e72', final:{left:120, top:90, rotate:0}, initial:{left:800, top:80}, delay:600 },

/* ㄷ (col=2 → originX = 200) */
{ id:'d1', color:'#f7d154', final:{left:200, top:50, rotate:0}, initial:{left:-200, top:-50}, delay:800 },
{ id:'d2', color:'#60a3fa', final:{left:206, top:55, rotate:90}, initial:{left:800, top:-50}, delay:1000 },
{ id:'d3', color:'#ff9f84', final:{left:200, top:90, rotate:0}, initial:{left:-200, top:150}, delay:1200 },

/* ㄹ (col=3 → originX = 280) */
{ id:'r1', color:'#9370db', final:{left:280, top:50, rotate:0, width:30}, initial:{left:-200, top:-20}, delay:1400 },
{ id:'r2', color:'#20b2aa', final:{left:318, top:50, rotate:90, width:30}, initial:{left:800, top:-20}, delay:1600 },
{ id:'r3', color:'#97e24b', final:{left:280, top:70, rotate:0, width:30}, initial:{left:-200, top:120}, delay:1800 },
{ id:'r4', color:'#daa520', final:{left:290, top:70, rotate:90, width:30}, initial:{left:800, top:120}, delay:2000 },
{ id:'r5', color:'#ff8c00', final:{left:288, top:90, rotate:0, width:30}, initial:{left:-200, top:10}, delay:2200 },

/* ㅁ (col=4 → originX = 360) */
{ id:'m1', color:'#fc7f52', final:{left:360, top:50, rotate:0}, initial:{left:-200, top:40}, delay:2400 },
{ id:'m2', color:'#569dd6', final:{left:366, top:55, rotate:90}, initial:{left:800, top:40}, delay:2600 },
{ id:'m3', color:'#8d59be', final:{left:360, top:90, rotate:0}, initial:{left:-200, top:100}, delay:2800 },
{ id:'m4', color:'#98cf61', final:{left:405, top:55, rotate:90}, initial:{left:800, top:100}, delay:3000 },

/* ㅂ (col=5 → originX = 440) */
{ id:'b1', color:'#ff6b81', final:{left:440, top:67, rotate:0}, initial:{left:-200, top:40}, delay:3200 },
{ id:'b2', color:'#74b9ff', final:{left:440, top:90, rotate:0}, initial:{left:800, top:20},  delay:3400 },
{ id:'b3', color:'#55efc4', final:{left:446, top:50, rotate:90, width:46}, initial:{left:-200, top:180}, delay:3600 },
{ id:'b4', color:'#ffeaa7', final:{left:484, top:50, rotate:90, width:46}, initial:{left:800, top:180}, delay:3800 },

/* ㅅ (col=6 → originX = 520) */
{ id:'s1', color:'#ff8f7d', final:{left:504, top:94, rotate:-45, width:62}, initial:{left:-300, top:40}, delay:4000 },
{ id:'s2', color:'#6c5ce7', final:{left:537, top:68, rotate:45, width:40}, initial:{left:900, top:40}, delay:4200 },


/* ================================
   2행 — ㅇ ㅈ ㅊ ㅋ ㅌ ㅍ ㅎ
================================ */

/* ㅇ (col=0 → x=40) — 도넛(circle) */
{
    id:'o_circle', type:'circle',
    color:'#00b894',
    final:{ left:47, top:149, size:45 },
    initial:{ left:-200, top:-200 },
    delay:4400
},

/* ㅈ (col=1 → x=120) */
{ id:'j1', color:'#a29bfe', final:{left:120, top:150, rotate:0, width:46}, initial:{left:-200, top:10}, delay:4600 },
{ id:'j2', color:'#ffeaa7', final:{left:114, top:186, rotate:-45, width:40}, initial:{left:800, top:100}, delay:4800 },
{ id:'j3', color:'#ffeaa7', final:{left:145, top:159, rotate:45, width:40}, initial:{left:-200, top:150}, delay:5000 },

/* ㅊ (col=2 → x=200) */
{ id:'c1', color:'#ff9f82', final:{left:203, top:145, rotate:0, width:32}, initial:{left:-200, top:10}, delay:5200 },
{ id:'c2', color:'#ff7675', final:{left:197, top:160, rotate:0, width:46}, initial:{left:800, top:20}, delay:5400 },
{ id:'c3', color:'#55efc4', final:{left:198, top:185, rotate:-45, width:33}, initial:{left:-200, top:100}, delay:5600 },
{ id:'c4', color:'#55efc4', final:{left:220, top:163, rotate:45, width:33}, initial:{left:800, top:150}, delay:5800 },

/* ㅋ (col=3 → x=280) */
{ id:'k1', color:'#ff6b6b', final:{left:277, top:150, rotate:0}, initial:{left:-200, top:40}, delay:6000 },
{ id:'k2', color:'#74b9ff', final:{left:318, top:150, rotate:90, width:45}, initial:{left:800, top:60}, delay:6200 },
{ id:'k3', color:'#55efc4', final:{left:277, top:170, rotate:0}, initial:{left:-200, top:120}, delay:6400 },

/* ㅌ (col=4 → x=360) */
{ id:'t1', color:'#ffeaa7', final:{left:360, top:140, rotate:0}, initial:{left:-200, top:20}, delay:6600 },
{ id:'t2', color:'#a29bfe', final:{left:340, top:160, rotate:0}, initial:{left:800, top:0}, delay:6800 },
{ id:'t3', color:'#a29bfe', final:{left:380, top:160, rotate:0}, initial:{left:-200, top:180}, delay:7000 },
{ id:'t4', color:'#fab1a0', final:{left:360, top:180, rotate:0}, initial:{left:800, top:180}, delay:7200 },

/* ㅍ (col=5 → x=440) */
{ id:'p1', color:'#ff7675', final:{left:440, top:145, rotate:0}, initial:{left:-200, top:40}, delay:7400 },
{ id:'p2', color:'#ff7675', final:{left:440, top:165, rotate:0}, initial:{left:800, top:20}, delay:7600 },
{ id:'p3', color:'#81ecec', final:{left:420, top:145, rotate:90}, initial:{left:-200, top:160}, delay:7800 },
{ id:'p4', color:'#81ecec', final:{left:460, top:145, rotate:90}, initial:{left:800, top:150}, delay:8000 },

/* ㅎ (col=6 → x=520) — 도넛 + 획 */
{
    id:'h_circle', type:'circle',
    color:'#55efc4',
    final:{ left:520, top:140, size:40 },
    initial:{ left:-200, top:-200 },
    delay:8200
},
{
    id:'h_line', color:'#ffeaa7',
    final:{ left:520, top:185, rotate:0, width:40 },
    initial:{ left:800, top:150 },
    delay:8400
}
];


const VOWEL_STROKES = [

/* ================================
   모음 1줄 — ㅏ ㅑ ㅓ ㅕ ㅗ ㅛ ㅜ ㅠ ㅡ ㅣ
================================ */

/* ㅏ (col=0 → x=40) */
{ id:'a1', color:'#0984e3', final:{left:40, top:80, rotate:90}, initial:{left:-200, top:0}, delay:0 },
{ id:'a2', color:'#55efc4', final:{left:70, top:90, rotate:0}, initial:{left:800, top:20}, delay:200 },

/* ㅑ (col=1 → x=120) */
{ id:'ya1', color:'#74b9ff', final:{left:120, top:80, rotate:90}, initial:{left:-200, top:40}, delay:400 },
{ id:'ya2', color:'#81ecec', final:{left:150, top:85, rotate:0}, initial:{left:800, top:0}, delay:600 },
{ id:'ya3', color:'#81ecec', final:{left:150, top:105, rotate:0}, initial:{left:-200, top:150}, delay:800 },

/* ㅓ (col=2 → x=200) */
{ id:'eo1', color:'#ff7675', final:{left:200, top:80, rotate:90}, initial:{left:-200, top:20}, delay:1000 },
{ id:'eo2', color:'#55efc4', final:{left:170, top:90, rotate:0}, initial:{left:800, top:20}, delay:1200 },

/* ㅕ (col=3 → x=280) */
{ id:'yeo1', color:'#6c5ce7', final:{left:280, top:80, rotate:90}, initial:{left:-200, top:0}, delay:1400 },
{ id:'yeo2', color:'#ffeaa7', final:{left:250, top:85, rotate:0}, initial:{left:800, top:100}, delay:1600 },
{ id:'yeo3', color:'#ffeaa7', final:{left:250, top:105, rotate:0}, initial:{left:-200, top:120}, delay:1800 },

/* ㅗ (col=4 → x=360) */
{ id:'o_v1', color:'#00cec9', final:{left:360, top:100, rotate:90}, initial:{left:-200, top:60}, delay:2000 },
{ id:'o_v2', color:'#fab1a0', final:{left:340, top:80, rotate:0}, initial:{left:800, top:10}, delay:2200 },

/* ㅛ (col=5 → x=440) */
{ id:'yo1', color:'#55efc4', final:{left:440, top:80, rotate:0}, initial:{left:-200, top:40}, delay:2400 },
{ id:'yo2', color:'#55efc4', final:{left:460, top:60, rotate:90}, initial:{left:800, top:0}, delay:2600 },
{ id:'yo3', color:'#55efc4', final:{left:460, top:100, rotate:90}, initial:{left:-200, top:100}, delay:2800 },

/* ㅜ (col=6 → x=520) */
{ id:'u1', color:'#a29bfe', final:{left:520, top:80, rotate:0}, initial:{left:-200, top:20}, delay:3000 },
{ id:'u2', color:'#00cec9', final:{left:540, top:60, rotate:90}, initial:{left:800, top:100}, delay:3200 },

/* ㅠ (col=7 → x=600) */
{ id:'yu1', color:'#e17055', final:{left:600, top:80, rotate:0}, initial:{left:-200, top:40}, delay:3400 },
{ id:'yu2', color:'#81ecec', final:{left:620, top:60, rotate:90}, initial:{left:800, top:0}, delay:3600 },
{ id:'yu3', color:'#81ecec', final:{left:620, top:100, rotate:90}, initial:{left:-200, top:150}, delay:3800 },

/* ㅡ (col=8 → x=680) */
{ id:'eu1', color:'#ffeaa7', final:{left:680, top:90, rotate:0, width:60}, initial:{left:-200, top:10}, delay:4000 },

/* ㅣ (col=9 → x=760) */
{ id:'i1', color:'#fab1a0', final:{left:760, top:60, rotate:90, height:60}, initial:{left:800, top:20}, delay:4200 }

];

/* ================================
   6. 실행
================================ */
$(document).ready(() => {
    createAndInitialize("#consonant-container", CONSONANT_STROKES);
    createAndInitialize("#vowel-container", VOWEL_STROKES);

    startAnimation(CONSONANT_STROKES);
    startAnimation(VOWEL_STROKES);

    applyScale("#consonant-wrapper", 700);
    applyScale("#vowel-wrapper", 700);

    $("#resetButton").on("click", () => {
        createAndInitialize("#consonant-container", CONSONANT_STROKES);
        createAndInitialize("#vowel-container", VOWEL_STROKES);

        setTimeout(() => {
            startAnimation(CONSONANT_STROKES);
            startAnimation(VOWEL_STROKES);
        }, 50);
    });
});
